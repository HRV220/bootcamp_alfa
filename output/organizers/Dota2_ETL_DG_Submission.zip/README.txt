Основной документ для организаторов: Dota2_ETL_DG_Passport.pdf
Редактируемый текст: Dota2_ETL_DG_Passport.md
В new, task и requirements сохранены использованные первоисточники.
sources.json содержит их полные пути и SHA-256.
